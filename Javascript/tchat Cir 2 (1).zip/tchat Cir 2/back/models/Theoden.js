class Theoden {
    constructor() {
        console.log('You have no power here!');
    }
}

module.exports = Theoden;