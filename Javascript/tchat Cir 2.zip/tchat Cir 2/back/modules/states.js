module.exports = {
    printServerStatus() {
        console.log('Server ok');
    },
    printProfStatus() {
        console.log('Need Coffee');
    }
}
